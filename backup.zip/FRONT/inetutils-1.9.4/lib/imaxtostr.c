#define anytostr imaxtostr
#define inttype intmax_t
#include "anytostr.c"
